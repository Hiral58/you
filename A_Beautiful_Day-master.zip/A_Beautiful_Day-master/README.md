# A_Beautiful_Day
A website footer is found at the bottom of your site pages. It typically includes important information such as a copyright notice, a disclaimer, or a few links to relevant resources. After all, it's what visitors first see when they land on a site.

![alt text](https://github.com/AhsanParadise/A_Beautiful_Day/blob/master/ScreenShot.jpg?raw=true)
